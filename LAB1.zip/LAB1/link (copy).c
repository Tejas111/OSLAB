#include<stdio.h>
#include<sys/types.h>
#include<sys/stat.h>
#include <fcntl.h> 
#include<errno.h>
#include<stdlib.h>
#include<string.h>
extern int errorno;
int main()
{
	char *c = (char *)malloc(50*(sizeof(char)));
	int S=creat("/home/tejaskumar/Desktop/tk.txt",S_IRWXU | S_IROTH | S_IRGRP);
	printf("fd=%d\n",S);
	int Z=open("tk.txt", O_RDWR );
	printf("fd=%d\n",Z);
	int y=write(Z,"tejaskumark",strlen("tejaskumark"));// to write
	printf("the number of bits written is %d\n",y);
	printf("fd=%d\n",Z);
	close(Z);
	// program to link a file to other and then to unlink the other
	int M= link("tk.txt","tn.txt");
	printf("%d",M);
	if(M==-1)
	{
		perror("");
	}
	
		
	
	
return 0;
}
	

