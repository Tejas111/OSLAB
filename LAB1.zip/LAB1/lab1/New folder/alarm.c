#include<stdio.h>
#include<unistd.h>
#include<signal.h>
void handler(int);
void handler( int signum )
{

printf("tejas\n");
exit(0);
}

int main()
{

signal( SIGALRM, handler );

alarm(10);

while(1);// trigger after every 10 seconds
}
