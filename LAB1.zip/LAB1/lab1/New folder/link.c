#include<stdio.h>
#include<sys/types.h>
#include<sys/stat.h>
#include <fcntl.h> 
#include<errno.h>
#include<stdlib.h>
#include<string.h>
extern int errorno;
int main()
{
	char *c = (char *)malloc(50*(sizeof(char)));
	umask(S_IROTH | S_IRGRP);
	int S=creat("/home/tejaskumar/Desktop/tk.txt",S_IRWXU | S_IROTH | S_IRGRP);
	
	
return 0;
}
	

