#include<stdio.h>
#include<sys/types.h>
#include<sys/stat.h>
#include <fcntl.h> 
#include<errno.h>
#include<stdlib.h>
#include<string.h>
extern int errorno;
int main()
{	
	//program to demonstrate the duplicte system call
	char *c = (char *)malloc(50*(sizeof(char)));
	int S=creat("/home/tejaskumar/Desktop/tk.txt",S_IRWXU | S_IROTH | S_IRGRP);
	int Z=open("tk.txt", O_RDWR );
	int f_cpy = dup(Z);
	write(Z,"tejaskumark\n",strlen("tejaskumark\n"));// to write
	write(f_cpy,"tejaskumark",strlen("tejaskumark"));
	printf("fd=%d of original\n",Z);// file descriptor before and after dup system call
	printf("fd=%d after dup\n",f_cpy);
	
	
	
return 0;
}
	

