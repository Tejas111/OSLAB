#include<string.h>
#include<stdio.h>
#include<unistd.h>
#include<sys/types.h>
#include<stdlib.h>
#include<sys/stat.h>
#include<fcntl.h>
#include<sys/ioctl.h>
#include<signal.h>
int main()
{
	int pid =getpid();
	if(kill(pid,0)!=0)
	{
		printf("error\n");
		exit(0);
	}
	printf("Succeded\n");
	exit(0);
}
