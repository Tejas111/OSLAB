#include<stdio.h>
#include<sys/types.h>
#include<sys/stat.h>
#include <fcntl.h> 
int main()
{
	int Z=open("tk.txt", O_RDONLY );
	printf("fd=%d\n",Z);
	if(Z==-1)
	{
		
		perror("error");
	}
	if(close(Z)<0)
	{
		perror("error");
	}
	printf("closed the file \n");
	
return 0;
}
