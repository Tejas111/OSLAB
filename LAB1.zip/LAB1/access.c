#include<stdio.h>
#include<sys/types.h>
#include<sys/stat.h>
#include <fcntl.h> 
#include<errno.h>
#include<stdlib.h>
#include<string.h>
#include<unistd.h>
extern int errno;
int main()
{
	char *c = (char *)malloc(50*(sizeof(char)));
	int S=creat("/home/tejaskumar/Desktop/tk.txt",S_IRWXU | S_IROTH | S_IRGRP);
	
	int Z=open("tk.txt", O_RDONLY );
	
	int fd=access("tk.txt",X_OK | W_OK);
	if(fd==-1)
	{
		printf("the error no is %d\n",errno);
		perror("error");
	}
	printf("fd=%d\n",fd);
	/*int y=write(Z,"tejaskumark",strlen("tejaskumark"));// to write
	printf("the number of bits written is %d\n",y);
	printf("fd=%d\n",Z);
	close(Z);
	int K=open("tk.txt", O_RDWR );
	printf("fd=%d\n",K);
	int t=read(K,c,5);
	c[t]='\0';
	printf("the number of bits read is %d and is %s\n", t,c);//to read*/ 
	
	
	
return 0;
}
	

